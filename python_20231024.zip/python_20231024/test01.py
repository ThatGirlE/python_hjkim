print("HelloWorld!!!")

print(1+1)
